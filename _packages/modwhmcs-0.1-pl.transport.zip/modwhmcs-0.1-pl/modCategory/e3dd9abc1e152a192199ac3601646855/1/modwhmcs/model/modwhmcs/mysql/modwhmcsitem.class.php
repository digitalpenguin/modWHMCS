<?php
require_once (dirname(dirname(__FILE__)) . '/modwhmcsitem.class.php');
class modWHMCSItem_mysql extends modWHMCSItem {}