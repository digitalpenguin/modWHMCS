<?php
class modWHMCSItem extends xPDOSimpleObject {}