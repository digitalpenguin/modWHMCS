--------------------
modWHMCS
--------------------
Version: 0.0.2
Author: Jan Peca <pecajan@gmail.com>
--------------------

A basic Extra for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/theboxer/modWHMCS/issues